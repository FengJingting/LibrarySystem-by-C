void listBooks( Book *bookList, int numBooks );
void listBorrowedBooks( Book *bookList, int numBooks );

void librarianCLI( Library *theLibrary );