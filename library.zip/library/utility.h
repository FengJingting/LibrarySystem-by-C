int optionChoice( void );
void removeNewLine(char* string);
